<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Request extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->form_validation->set_error_delimiters("<div class='error'>", "</div>");
	}

	public function index()
	{
		$this->data['title'] = 'Employee';
		$this->data['employee'] = $this->general_model->getAll('employee');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->data['request'] = $this->general_model->getAll('request', '','999999999999');
		$this->template->admin_render('admin/request/index', $this->data);
	}

	public function request_approve($id)
	{
		$data = array("request_approved" => "1");
		$this->general_model->update('request', array('id' => $id), $data);
		
		
		$request = $this->general_model->getOne('request', array('id' => $id));
		$employee = $this->general_model->getOne('employee', array('id' => $request->employee));
		$name = $employee->first_name." ".$employee->last_name;
		$this->send_push_notification(array($employee->device_id), $name, 'Your Request Approved.');
		
		redirect('admin/request/index', 'refresh');
	}
	
	public function request_denie($id)
	{
		$data = array("request_approved" => "2");
		$this->general_model->update('request', array('id' => $id), $data);
		
		$request = $this->general_model->getOne('request', array('id' => $id));
		$employee = $this->general_model->getOne('employee', array('id' => $request->employee));
		$name = $employee->first_name." ".$employee->last_name;
		$this->send_push_notification(array($employee->device_id), $name, 'Your Request Rejected.');
		
		redirect('admin/request/index', 'refresh');
	}
	
	public function view_desc($id)
	{
		$this->data['request'] = $this->general_model->getOne('request', array('id' => $id));
		$this->load->view('admin/request/view_request', $this->data);
	}
}
