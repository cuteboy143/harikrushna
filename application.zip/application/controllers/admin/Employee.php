<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Employee extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->form_validation->set_error_delimiters("<div class='error'>", "</div>");
	}

	public function index()
	{
		$this->data['title'] = 'Employee';
		$this->data['employee'] = $this->general_model->getAll('employee');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->template->admin_render('admin/employee/index', $this->data);
	}

	public function add()
	{
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		$this->form_validation->set_rules('lattitude', 'lattitude', 'required');
		$this->form_validation->set_rules('longitude', 'longitude', 'required');
		$this->form_validation->set_rules('manager', 'manager', 'required');
		$this->form_validation->set_rules('department', 'department', 'required');
		$this->form_validation->set_rules('entity', 'entity', 'required');

		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'email' => $this->input->post('email'),
					'password' => $this->input->post('password'),
					'phone' => $this->input->post('phone'),
					'lattitude' => $this->input->post('lattitude'),
					'longitude' => $this->input->post('longitude'),
					'manager' => $this->input->post('manager'),
					'department' => $this->input->post('department'),
					'entity' => $this->input->post('entity'),
					'created_on' => date("Y-m-d H:i:s"),
				);
				
				if ($this->general_model->insert('employee', $data)) 
				{
					$this->session->set_flashdata('message', array('1', 'Employee successfully added.'));
					redirect('admin/employee', 'refresh');
				} 
				else 
				{
					$this->session->set_flashdata('message', array('0', 'Somting went to wrong.'));
					redirect('admin/employee', 'refresh');
				}
			}
		}
		$this->data['title'] = 'Add Employee';
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->template->admin_render('admin/employee/add', $this->data);
	}
	
	public function edit($id)
	{
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		$this->form_validation->set_rules('lattitude', 'lattitude', 'required');
		$this->form_validation->set_rules('longitude', 'longitude', 'required');
		$this->form_validation->set_rules('manager', 'manager', 'required');
		$this->form_validation->set_rules('department', 'department', 'required');
		$this->form_validation->set_rules('entity', 'entity', 'required');

		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'email' => $this->input->post('email'),
					'password' => $this->input->post('password'),
					'phone' => $this->input->post('phone'),
					'lattitude' => $this->input->post('lattitude'),
					'longitude' => $this->input->post('longitude'),
					'manager' => $this->input->post('manager'),
					'department' => $this->input->post('department'),
					'entity' => $this->input->post('entity'),
					'updated_on' => date("Y-m-d H:i:s"),
					
				);
				$this->general_model->update('employee', array('id' => $id), $data);
				$this->session->set_flashdata('message', array('1', 'Employee successfully updated.'));
				redirect('admin/employee', 'refresh');
			}
		}

		$this->data['title'] = 'Edit Employee';
		$this->data['employee'] = $this->general_model->getOne('employee', array('id' => $id));
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->template->admin_render('admin/employee/edit', $this->data);
	}



	public function delete($id)
	{
		
		$question = $this->general_model->getOne('employee', array('id' => $id));
		if ($question) {
			$delete = $this->general_model->delete('employee', array('id' => $id));
			$this->session->set_flashdata('message', array('1', 'Employee successfully deleted.'));
		}
		redirect('admin/employee', 'refresh');
	}
	
	public function view($id)
	{
	    $this->data['employee'] = $this->general_model->getOne('employee', array('id' => $id));
		$this->load->view('admin/employee/view', $this->data);
	}
	
	public function location($id)
	{
	    $this->data['employee'] = $this->general_model->getOne('employee', array('id' => $id));
		$this->load->view('admin/employee/location', $this->data);
	}


	public function selectEntityAjax() 
	{
		$postData = $this->input->post("ent");
		if(!empty($postData))
		{
       		$result = $this->general_model->getAll('department', array('entity' => $postData));
       		echo json_encode($result);
		}
   	}

   	public function selectDepartmentAjax() 
	{
		$depData = $this->input->post("dep");
		$entData = $this->input->post("ent");
		if(!empty($depData) && !empty($entData))
		{
       		$result = $this->general_model->getAll('manager', array('entity' => $entData, 'department' => $depData));
       		echo json_encode($result);
		}
   }
}
