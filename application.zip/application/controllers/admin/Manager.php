<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Manager extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->form_validation->set_error_delimiters("<div class='error'>", "</div>");
	}

	public function index()
	{
		$this->data['title'] = 'Manager';
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->template->admin_render('admin/manager/index', $this->data);
	}

	public function add()
	{
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		$this->form_validation->set_rules('entity', 'entity', 'required');
		$this->form_validation->set_rules('department', 'department', 'required');

		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'email' => $this->input->post('email'),
					'password' => md5($this->input->post('password')),
					'phone' => $this->input->post('phone'),
					'entity' => $this->input->post('entity'),
					'department' => $this->input->post('department'),
					'group_id' => "2",
					'created_on' => date("Y-m-d H:i:s"),
				);
				if ($this->general_model->insert('manager', $data)) 
				{
					$this->session->set_flashdata('message', array('1', 'Manager successfully added.'));
					redirect('admin/manager', 'refresh');
				} 
				else 
				{
					$this->session->set_flashdata('message', array('0', 'Somting went to wrong.'));
					redirect('admin/manager', 'refresh');
				}
			}
		}
		$this->data['title'] = 'Add Manager';
		//$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->template->admin_render('admin/manager/add', $this->data);
	}
	
	public function edit($id)
	{
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		$this->form_validation->set_rules('entity', 'entity', 'required');
		$this->form_validation->set_rules('department', 'department', 'required');

		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'first_name' => $this->input->post('first_name'),
					'last_name' => $this->input->post('last_name'),
					'email' => $this->input->post('email'),
					'phone' => $this->input->post('phone'),
					'entity' => $this->input->post('entity'),
					'department' => $this->input->post('department'),
					'group_id' => "2",
					'updated_on' => date("Y-m-d H:i:s"),
					
				);
				$this->general_model->update('manager', array('id' => $id), $data);
				$this->session->set_flashdata('message', array('1', 'Manager successfully updated.'));
				redirect('admin/manager', 'refresh');
			}
		}

		$this->data['title'] = 'Edit Manager';
		$this->data['manager'] = $this->general_model->getOne('manager', array('id' => $id));
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->template->admin_render('admin/manager/edit', $this->data);
	}



	public function delete($id)
	{
		
		$question = $this->general_model->getOne('manager', array('id' => $id));
		if ($question) {
			$delete = $this->general_model->delete('manager', array('id' => $id));
			$this->session->set_flashdata('message', array('1', 'Manager successfully deleted.'));
		}
		redirect('admin/manager', 'refresh');
	}


	public function selectAjax() 
	{
		$postData = $this->input->post("ent");
		if(!empty($postData))
		{
       		$result = $this->general_model->getAll('department', array('entity' => $postData));
       		echo json_encode($result);
		}
   }
}
