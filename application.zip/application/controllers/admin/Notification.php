<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Notification extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->form_validation->set_error_delimiters("<div class='error'>", "</div>");
	}

	public function index()
	{
		$this->data['title'] = 'Notification';
		$this->data['notification'] = $this->general_model->getAll('notification');
		$this->template->admin_render('admin/notification/index', $this->data);
	}

	public function add()
	{
		$this->form_validation->set_rules('title', 'title', 'required');
		$this->form_validation->set_rules('description', 'description', 'required');
		
		$employee = $this->db->select('device_id')->get("employee")->result();
        
		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'title' => $this->input->post('title'),
					'description' => $this->input->post('description'),
					'created_on' => date("Y-m-d H:i:s"),
				);
				
				if ($this->general_model->insert('notification', $data)) 
				{
				    $device_id = [];
				    
            	    foreach($employee as $e_val)
            	    {
            	        if(!empty($e_val->device_id))
            	        {
            	            $device_id[] = $e_val->device_id;
            	        }
            	    }
				    
				    $this->send_push_notification($device_id, $this->input->post('title'), $this->input->post('description'));
				    
					$this->session->set_flashdata('message', array('1', 'Notification successfully added.'));
					redirect($_SERVER["HTTP_REFERER"]);
				} 
				else 
				{
					$this->session->set_flashdata('message', array('0', 'Somting went to wrong.'));
					redirect($_SERVER["HTTP_REFERER"]);
				}
			}
		}
		$this->data['title'] = 'Add Notification';
		$this->load->view('admin/notification/add', $this->data);
	}
	
	public function edit($id)
	{
		$this->form_validation->set_rules('title', 'title', 'required');
		$this->form_validation->set_rules('description', 'description', 'required');

		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'title' => $this->input->post('title'),
					'description' => $this->input->post('description'),
					'updated_on' => date("Y-m-d H:i:s"),
					
				);
				$this->general_model->update('notification', array('id' => $id), $data);
				$this->session->set_flashdata('message', array('1', 'Notification successfully updated.'));
				redirect($_SERVER["HTTP_REFERER"]);
			}
		}

		$this->data['title'] = 'Edit Notification';
		$this->data['notification'] = $this->general_model->getOne('notification', array('id' => $id));
		$this->load->view('admin/notification/edit', $this->data);
	}



	public function delete($id)
	{
		
		$question = $this->general_model->getOne('notification', array('id' => $id));
		if ($question) {
			$delete = $this->general_model->delete('notification', array('id' => $id));
			$this->session->set_flashdata('message', array('1', 'Notification successfully deleted.'));
		}
		redirect('admin/notification', 'refresh');
	}
	
	public function view($id)
	{
	    $this->data['notification'] = $this->general_model->getOne('notification', array('id' => $id));
		$this->load->view('admin/notification/view', $this->data);
	}
}
