<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Profile extends Admin_Controller {
	public function __construct() {
		parent::__construct();
		$this->form_validation->set_error_delimiters("<div class='error'>", "</div>");
	}

	public function index() {
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('company_name', 'company name', 'required');
		if ($this->input->post('password')) {
			$this->form_validation->set_rules('password', 'password', 'required|min_length[5]|matches[c_password]');
			$this->form_validation->set_rules('c_password', 'confirm password', 'required');
		}

		$profile_image = '';
		if (isset($_POST) && !empty($_POST)) {

			if (!empty($_FILES['profile']['name'])) {
				/* Conf Image */
				$file_name = 'profile_' . time() . rand(100, 999);
				$configImg['upload_path'] = './uploads/profile/';
				$configImg['file_name'] = $file_name;
				$configImg['allowed_types'] = 'png|jpg|jpeg|JPG|JPEG';
				$configImg['max_size'] = 2000;
				$configImg['max_width'] = 2000;
				$configImg['max_height'] = 2000;
				$configImg['file_ext_tolower'] = TRUE;
				$configImg['remove_spaces'] = TRUE;

				$this->load->library('upload', $configImg, 'profile');
				if ($this->profile->do_upload('profile')) {
					$uploadData = $this->profile->data();
					$profile_image = 'uploads/profile/' . $uploadData['file_name'];
				} else {
					$this->custom_errors['profile'] = $this->profile->display_errors('', '');
				}
			}
		}
		$this->form_validation->set_rules('profile', '', 'callback_image_validation');
		if ($this->form_validation->run() == true) {
			$update = array(
				'name' => $this->input->post('name'),
				'company_name' => $this->input->post('company_name'),
				'phone' => $this->input->post('phone'),
			);

			if (($this->input->post('password') !== null) && $this->input->post('password') !== "") {
				$update['password'] = md5($this->input->post('password'));
			}

			if (!empty($profile_image)) {
				if (file_exists($this->user->profile_image)) {
					unlink($this->user->profile_image);
				}
				$update['profile_image'] = $profile_image;
			}
			if ($id = $this->general_model->update('users', array('id' => $this->session->userdata('id')), $update)) {
				$this->session->set_flashdata('message', array('1', 'Profile Updated Successfully.'));
			} else {
				$this->session->set_flashdata('message', array('0', 'Someting went to wrong'));
			}
			redirect('admin/profile', 'refresh');
		}
		$this->data['title'] = 'Edit Profile';
		$this->template->admin_render('admin/profile/index', $this->data);
	}

	function image_validation($str) {
		#unused $str
		if (isset($this->custom_errors['profile'])) {
			$this->form_validation->set_message('image_validation', $this->custom_errors['profile']);
			return FALSE;
		}
		return TRUE;
	}
}
