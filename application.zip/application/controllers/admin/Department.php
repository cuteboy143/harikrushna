<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Department extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->form_validation->set_error_delimiters("<div class='error'>", "</div>");
	}

	public function index()
	{
		$this->data['title'] = 'Department';
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->template->admin_render('admin/department/index', $this->data);
	}

	public function add()
	{
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('entity', 'entity', 'required');
		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'name' => $this->input->post('name'),
					'entity' => $this->input->post('entity'),
					'created_on' => date("Y-m-d H:i:s"),
				);

				if ($this->general_model->insert('department', $data)) 
				{
					$this->session->set_flashdata('message', array('1', 'Department successfully added.'));
					redirect('admin/department', 'refresh');
				} 
				else 
				{
					$this->session->set_flashdata('message', array('0', 'Somting went to wrong.'));
					redirect('admin/department', 'refresh');
				}
			}
		}
		$this->data['title'] = 'Add Department';
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->template->admin_render('admin/department/add', $this->data);
	}

	
	public function edit($id)
	{
		$this->form_validation->set_rules('name', 'name', 'required');
		$this->form_validation->set_rules('entity', 'entity', 'required');
		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'name' => $this->input->post('name'),
					'entity' => $this->input->post('entity'),
					'updated_on' => date("Y-m-d H:i:s"),
				);
				$this->general_model->update('department', array('id' => $id), $data);
				$this->session->set_flashdata('message', array('1', 'Department successfully updated.'));
				redirect('admin/department', 'refresh');
			}
		}
		$this->data['title'] = 'Edit Department';
		$this->data['department'] = $this->general_model->getOne('department', array('id' => $id));
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->template->admin_render('admin/department/edit', $this->data);
	}



	public function delete($id)
	{
		
		$question = $this->general_model->getOne('department', array('id' => $id));
		if ($question) {
			$delete = $this->general_model->delete('department', array('id' => $id));
			$this->session->set_flashdata('message', array('1', 'Department successfully deleted.'));
		}
		redirect('admin/department', 'refresh');
	}
}
