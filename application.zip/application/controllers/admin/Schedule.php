<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Schedule extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->form_validation->set_error_delimiters("<div class='error'>", "</div>");
	}

	public function index()
	{
		$this->data['title'] = 'Schedule';
		$this->data['employee'] = $this->general_model->getAll('employee');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->data['schedule'] = $this->general_model->getAll('schedule');
		$this->template->admin_render('admin/schedule/index', $this->data);
	}

	public function add()
	{
		$this->form_validation->set_rules('entity', 'entity', 'required');
		$this->form_validation->set_rules('department', 'department', 'required');
		$this->form_validation->set_rules('manager', 'manager', 'required');
		$this->form_validation->set_rules('employee', 'employee', 'required');

		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$data = array(
					'entity' => $this->input->post('entity'),
					'department' => $this->input->post('department'),
					'manager' => $this->input->post('manager'),
					'employee' => $this->input->post('employee'),
					'created_on' => date("Y-m-d H:i:s"),
				);
				
				$sch_id = $this->general_model->insert('schedule', $data);
				if ($sch_id) 
				{
				    $shift_id = $this->input->post('shift_id');
				    $date = $this->input->post('date');
				    $start_time = $this->input->post('start_time');
				    $end_time = $this->input->post('end_time');
			        
			        $sch_arr = [];
				    foreach($date as $date_key => $date_val)
                    {
                        $sch_arr[] = array("shift_id" => $shift_id[$date_key], "date" => $date[$date_key], "start_time" => $start_time[$date_key], "end_time" => $end_time[$date_key]);
                    }
                    
                    if(!empty($sch_arr))
                    {
                        foreach($sch_arr as $sch_key => $sch_val)
                        {
                            $sch_data = array(
            					'schedule_tbl_id' => $sch_id,
            					'shift_id' => $sch_val['shift_id'],
            					'date' => $sch_val['date'],
            					'start_time' => $sch_val['start_time'],
            					'end_time' => $sch_val['end_time'],
            					'shift_status' => "initiated",
            					'created_on' => date("Y-m-d H:i:s"),
            				);
            				$this->general_model->insert('schedule_shift', $sch_data);
                        }
                    }
				    
				    
					$this->session->set_flashdata('message', array('1', 'Schedule successfully added.'));
					redirect('admin/schedule', 'refresh');
				} 
				else 
				{
					$this->session->set_flashdata('message', array('0', 'Somting went to wrong.'));
					redirect('admin/schedule', 'refresh');
				}
			}
		}
		$this->data['title'] = 'Add Schedule';
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->template->admin_render('admin/schedule/add', $this->data);
	}
	
	public function edit($id)
	{
		$this->form_validation->set_rules('entity', 'entity', 'required');
		$this->form_validation->set_rules('department', 'department', 'required');
		$this->form_validation->set_rules('manager', 'manager', 'required');
		$this->form_validation->set_rules('employee', 'employee', 'required');

		if ($_POST) 
		{
			if ($this->form_validation->run() == true) 
			{
				$shift_id = $this->input->post('shift_id');
			    $date = $this->input->post('date');
			    $start_time = $this->input->post('start_time');
			    $end_time = $this->input->post('end_time');
		        
		        $sch_arr = [];
			    foreach($date as $date_key => $date_val)
                {
                    $sch_arr[] = array("shift_id" => $shift_id[$date_key], "date" => $date[$date_key], "start_time" => $start_time[$date_key], "end_time" => $end_time[$date_key]);
                }
                
                if(!empty($sch_arr))
                {
                    foreach($sch_arr as $sch_key => $sch_val)
                    {
                        $sch_data = array(
                            'schedule_tbl_id' => $id,
        					'shift_id' => $sch_val['shift_id'],
        					'date' => $sch_val['date'],
        					'start_time' => $sch_val['start_time'],
        					'end_time' => $sch_val['end_time'],
        					'shift_status' => "initiated",
        					'updated_on' => date("Y-m-d H:i:s"),
        				);
                        
                        if($this->general_model->getAll('schedule_shift', array("shift_id" => $sch_val['shift_id'])))
                        {
        				    $this->general_model->update('schedule_shift', array('schedule_tbl_id' => $id, 'shift_id' => $sch_val['shift_id']), $sch_data);
                        }
                        else
                        {
                            $this->general_model->insert('schedule_shift', $sch_data);
                        }
                    }
                }
                
				$this->session->set_flashdata('message', array('1', 'Schedule successfully updated.'));
				redirect('admin/schedule', 'refresh');
			}
		}

		$this->data['title'] = 'Edit Employee';
		$this->data['entity'] = $this->general_model->getAll('entity');
		$this->data['department'] = $this->general_model->getAll('department');
		$this->data['manager'] = $this->general_model->getAll('manager');
		$this->data['employee'] = $this->general_model->getAll('employee');
		$this->data['schedule'] = $this->general_model->getOne('schedule', array("id" => $id));
		$this->data['schedule_shift'] = $this->general_model->getAll('schedule_shift', array("schedule_tbl_id" => $id));
		$this->template->admin_render('admin/schedule/edit', $this->data);
	}



	public function delete($id)
	{
		$question = $this->general_model->getOne('schedule', array('id' => $id));
		if ($question) {
			$delete = $this->general_model->delete('schedule', array('id' => $id));
			$this->session->set_flashdata('message', array('1', 'Schedule successfully deleted.'));
		}
		redirect('admin/schedule', 'refresh');
	}
	
	public function view($id)
	{
	    $this->data['schedule'] = $this->general_model->getOne('schedule', array("id" => $id));
	    $this->data['schedule_shift'] = $this->general_model->getAll('schedule_shift', array("schedule_tbl_id" => $id));
		$this->load->view('admin/schedule/view', $this->data);
	}


	public function selectEntityAjax() 
	{
		$postData = $this->input->post("ent");
		if(!empty($postData))
		{
       		$result = $this->general_model->getAll('department', array('entity' => $postData));
       		echo json_encode($result);
		}
   	}

   	public function selectDepartmentAjax() 
	{
		$depData = $this->input->post("dep");
		$entData = $this->input->post("ent");
		if(!empty($depData) && !empty($entData))
		{
       		$result = $this->general_model->getAll('manager', array('entity' => $entData, 'department' => $depData));
       		echo json_encode($result);
		}
    }

    public function selectManagerAjax() 
	{
		$depData = $this->input->post("dep");
		$entData = $this->input->post("ent");
		$managerData = $this->input->post("manager");

		if(!empty($depData) && !empty($entData) && !empty($managerData))
		{
       		$result = $this->general_model->getAll('employee', array('entity' => $entData, 'department' => $depData, 'manager' => $managerData));
       		echo json_encode($result);
		}
    }
}
