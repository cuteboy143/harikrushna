<div class="app-content icon-content">
    <div class="p-5"></div>
    <div class="section">
        <!-- Row opened -->
        <div class="row">
            <div class="col-lg-12">
                <?php if ($this->session->flashdata('message') !== NULL) {?>
                    <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php print_r($this->session->flashdata('message')['1']);?>
                    </div>
                <?php }?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><?= $title ?></h3>
                    </div>
                    <?php $attr = array('id' => 'edit_profile');?>
                    <?php echo form_open_multipart(current_url(), $attr); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Entity</label>
                                    <select class="form-control select-2 text-uppercase" name="entity" id="select_ent">
                                        <option value="" class="text-uppercase">Select Entity</option>
                                        <?php
                                        if(count($entity)>0)
                                        {
                                            foreach($entity as $de_val)
                                            {
                                                ?>
                                                <option value="<?= $de_val->id;?>" class="text-uppercase" ><?= $de_val->name;?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error('entity'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Deaprtment</label>
                                    <select class="form-control select-2 text-uppercase" name="department" id="select_department">
                                        <option value="" class="text-uppercase">Select Department</option>
                                    </select>
                                    <?php echo form_error('department'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Manager</label>
                                    <select class="form-control select-2 text-uppercase" name="manager" id="manager">
                                        <option value="" class="text-uppercase">Select Manager</option>
                                    </select>
                                    <?php echo form_error('manager'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">First Name</label>
                                    <input type="text" name="first_name" class="form-control" >
                                    <?php echo form_error('first_name'); ?>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Last Name</label>
                                    <input type="text" name="last_name" class="form-control" >
                                    <?php echo form_error('last_name'); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Email</label>
                                    <input type="email" name="email" class="form-control" autocomplete="address-level4">
                                    <?php echo form_error('email'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Phone</label>
                                    <input type="number" name="phone" class="form-control" >
                                    <?php echo form_error('phone'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Password</label>
                                    <input type="password" name="password" class="form-control" >
                                    <?php echo form_error('password'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Lattitude</label>
                                    <input type="text" name="lattitude" class="form-control" >
                                    <?php echo form_error('lattitude'); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Longitude</label>
                                    <input type="text" name="longitude" class="form-control" >
                                    <?php echo form_error('longitude'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success mt-1">Add</button>
                        <a href="<?= base_url('admin/employee') ?>" class="btn btn-secondary mt-1">Cancel</a>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
        <!-- Row closed -->
    </div>
</div>

<script>
    jQuery(document).ready(function(){
        jQuery("#select_ent").change(function(){
            var entID = jQuery(this).val();
            if(entID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Employee/selectEntityAjax/',
                    type: "POST",
                    data: {
                        ent:entID,
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#depart').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="department"]').append('<option value="'+ value.id +'">'+ value.name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });

        jQuery("#select_department").change(function(){
            var depID = jQuery(this).val();
            var entID = jQuery("#select_ent").find(":selected").val();

            if(depID || entID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Employee/selectDepartmentAjax/',
                    type: "POST",
                    data: {
                        dep:depID,
                        ent:entID,
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#manager').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="manager"]').append('<option value="'+ value.id +'">'+ value.first_name +' '+ value.last_name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });
    });
</script>