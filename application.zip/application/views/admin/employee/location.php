<style>
button.dt-button {
    color: #fff !important;
    background-color: #0576b9 !important;
    border-color: #0576b9 !important;
}
</style>
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?= $employee->first_name." ".$employee->last_name;?> Location</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div id="map_canvas" class="mapping"></div>
        </div>
        <div class="modal-footer text-center">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>


<script type="text/javascript">
    function initialize()
    {
        var map;
        var bounds = new google.maps.LatLngBounds();
        var markers = [ [<?= $employee->emp_long?>, <?= $employee->emp_lat;?>] ];
        
        var mapOptions = {
            zoom: 10,
            center: new google.maps.LatLng(<?php echo $employee->emp_lat;?>, <?php echo $employee->emp_long;?>),
            mapTypeId: 'roadmap',
            gestureHandling: 'greedy'
        };
    
        map = new google.maps.Map(document.getElementById("map_canvas"), mapOptions);
        map.setTilt(45);
    
        var infoWindowContent = [ ['<?php echo $employee->first_name; ?>'], ['<?php echo $employee->last_name; ?>']];
    
        // Display multiple markers on a map
        var infoWindow = new google.maps.InfoWindow(), marker, i;
    
        // Loop through our array of markers & place each one on the map 
        for( i = 0; i < markers.length; i++ )
        {
            var position = new google.maps.LatLng(markers[i][1], markers[i][0]);
            bounds.extend(position);
            latpin = <?php echo $employee->emp_lat;?>;
            longpin = <?php echo $employee->emp_long;?>;
                //console.log(latpin + '-imhere-' + longpin);
            if(markers[i][0]==longpin && markers[i][1]==latpin)
            {
                marker = new google.maps.Marker({
                    position: position,
                    map: map,
                    icon: {
                      url: 'https://maps.gstatic.com/mapfiles/transparent.png',
                    },
                });
            }
           
            // Allow each marker to have an info window    
            google.maps.event.addListener(marker, 'click', (function(marker, i) {
                //console.log(infoWindowContent[i][0]);
                return function() {
                    infoWindow.setContent(infoWindowContent[i][0]);
                    infoWindow.open(map, marker);
                }
            })(marker, i));
    
            // Automatically center the map fitting all markers on the screen
            map.fitBounds(bounds);
        }
    
    
    
        // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
        var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
            this.setZoom(10);
            this.setCenter({lat: <?php echo $employee->emp_lat;?>, lng: <?php echo $employee->emp_long;?>});
            google.maps.event.removeListener(boundsListener);
        });
    }
</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAeUyQa48HEw5nu7I_KioFhIvBzBzjA76w&callback=initialize"></script>