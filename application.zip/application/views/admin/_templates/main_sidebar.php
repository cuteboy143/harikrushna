<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar toggle-sidebar">
    <ul class="side-menu toggle-menu">
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/dashboard');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/dashboard.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">DASHBOARD</span>
            </a>
        </li>
        
        <!-- <li class="slide">
            <a class="side-menu__item" href="<?//=base_url('admin/staff');?>">
                <span class="icon-menu-img"><img src="<?//=base_url('assets/images/menu/customers.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">STAFF</span>
            </a>
        </li> -->
        
        <?php
        if($this->session->userdata['group_id'] != 2)
        {
            ?>
            <li class="slide">
                <a class="side-menu__item" href="<?=base_url('admin/entity');?>">
                    <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                            class="side_menu_img svg-1" alt="image"></span>
                    <span class="side-menu__label">Entity</span>
                </a>
            </li>
            <li class="slide">
                <a class="side-menu__item" href="<?=base_url('admin/department');?>">
                    <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                            class="side_menu_img svg-1" alt="image"></span>
                    <span class="side-menu__label">Department</span>
                </a>
            </li>
            <li class="slide">
                <a class="side-menu__item" href="<?=base_url('admin/manager');?>">
                    <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                            class="side_menu_img svg-1" alt="image"></span>
                    <span class="side-menu__label">MANAGER</span>
                </a>
            </li>
            <?php
        }
        ?>

        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/employee');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">EMPLOYEE</span>
            </a>
        </li>
        
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/schedule');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">SCHEDULE</span>
            </a>
        </li>

        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/request');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">REQUEST</span>
            </a>
        </li>
        
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/notification');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">Notifications</span>
            </a>
        </li>

    </ul>
</aside>
