<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="app-content icon-content">
    <div class="section">
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard');?>"><i class="fa fa-dashboard mr-1"></i> Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Request</li>
            </ol>
        </div>
        <?php if ($this->session->flashdata('message') !== NULL) {?>
            <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php print_r($this->session->flashdata('message')['1']);?>
            </div>
        <?php }?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Request</h4>
                    </div>
                    <div class="card-body">
                        <div class="user-table">
                            <div class="table-responsive">
                                <table id="tables" class="table table-striped table-bordered text-nowrap dataTable no-footer dtr-inline">
                                    <thead>
                                        <tr>
                                            <th>Sr No</th>
                                            <th class="border-bottom-0">Entity</th>
                                            <th class="border-bottom-0">Department</th>
                                            <th class="border-bottom-0">Manager</th>
                                            <th class="border-bottom-0">Employee</th>
                                            <th class="border-bottom-0">Description</th>
                                            <th class="border-bottom-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = 0; 
                                        if($request)
                                        { 
                                            foreach($request as $key => $sta)
                                            { 
                                                $no = $no + 1;
                                                ?>
                                                <tr>
                                                    <td><?=$no?></td>
                                                    <td>
                                                        <?php 
                                                        if($entity)
                                                        {
                                                            foreach($entity as $en_val)
                                                            {
                                                                if($en_val->id == $sta->entity)
                                                                {
                                                                    echo $en_val->name;
                                                                }
                                                            }
                                                        }
                                                        ?>        
                                                    </td>
                                                    <td>
                                                        <?php 
                                                        if($department)
                                                        {
                                                            foreach($department as $de_val)
                                                            {
                                                                if($de_val->id == $sta->department)
                                                                {
                                                                    echo $de_val->name;
                                                                }
                                                            }
                                                        }
                                                        ?>        
                                                    </td>
                                                    
                                                    <td>
                                                        <?php 
                                                        if($manager)
                                                        {
                                                            foreach($manager as $mang_val)
                                                            {
                                                                if($mang_val->id == $sta->manager)
                                                                {
                                                                    echo $mang_val->first_name." ".$mang_val->last_name;
                                                                }
                                                            }
                                                        }
                                                        ?>        
                                                    </td>
                                                    <td>
                                                        <?php 
                                                        if($employee)
                                                        {
                                                            foreach($employee as $emp_val)
                                                            {
                                                                if($emp_val->id == $sta->employee)
                                                                {
                                                                    echo $emp_val->first_name." ".$emp_val->last_name;
                                                                }
                                                            }
                                                        }
                                                        ?>        
                                                    </td>
                                                    <td><a  data-toggle="data-toggle/data-dismiss" data-target="#customModel" class="btn btn-primary" href="<?=base_url('admin/request/view_desc/'.$sta->id);?>">View</a></td>
                                                    <td>
                                                    <?php
                                                    if($sta->request_approved == "" || $sta->request_approved == "0")
                                                    {
                                                        ?>
                                                        <a class="btn btn-primary" href="<?=base_url('admin/request/request_approve/'.$sta->id);?>">Approve!</a>
                                                        <a class="btn btn-danger" href="<?=base_url('admin/request/request_denie/'.$sta->id);?>">Reject!</a>
                                                        <?php
                                                    }
                                                    elseif($sta->request_approved == "1")
                                                    {
                                                        echo "Approved";
                                                    }
                                                    elseif($sta->request_approved == "2")
                                                    {
                                                        echo "Rejected";
                                                    }
                                                    ?>
                                                    
                                                </tr>
                                                <?php 
                                            } 
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
