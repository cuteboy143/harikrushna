<div class="app-content icon-content">
    <div class="p-5"></div>
    <div class="section">
        <!-- Row opened -->
        <div class="row">
            <div class="col-lg-12">
                <?php if ($this->session->flashdata('message') !== NULL) {?>
                    <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php print_r($this->session->flashdata('message')['1']);?>
                    </div>
                <?php }?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><?= $title ?></h3>
                    </div>
                    <?php $attr = array('id' => 'edit_profile');?>
                    <?php echo form_open_multipart(current_url(), $attr); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Entity</label>
                                    <select class="form-control select-2 text-uppercase" name="entity" id="select_ent">
                                        <option value="" class="text-uppercase">Select Entity</option>
                                        <?php
                                        if(count($entity)>0)
                                        {
                                            foreach($entity as $de_val)
                                            {
                                                ?>
                                                <option value="<?= $de_val->id;?>" class="text-uppercase" ><?= $de_val->name;?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error('entity'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Deaprtment</label>
                                    <select class="form-control select-2 text-uppercase" name="department" id="select_department">
                                        <option value="" class="text-uppercase">Select Department</option>
                                    </select>
                                    <?php echo form_error('department'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Manager</label>
                                    <select class="form-control select-2 text-uppercase" name="manager" id="manager">
                                        <option value="" class="text-uppercase">Select Manager</option>
                                    </select>
                                    <?php echo form_error('manager'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Employee</label>
                                    <select class="form-control select-2 text-uppercase" name="employee" id="employee">
                                        <option value="" class="text-uppercase">Select Employee</option>
                                    </select>
                                    <?php echo form_error('employee'); ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="sch_row">
                            <div class="row">
                                <input type="hidden" name="shift_id[]" value="1">
                                <div class="col-md-4">
                                    <div class="form-group" style="width:100%;">
                                        <label for="description" class="col-form-label">Date</label>
                                        <input type="date" name="date[]" id="sch_date" class="form-control" >
                                        <?php //echo form_error('date'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group" style="width:100%;">
                                        <label for="description" class="col-form-label">Start Time</label>
                                        <input type="time" name="start_time[]" class="form-control" >
                                        <?php //echo form_error('start_time'); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group" style="width:100%;">
                                        <label for="description" class="col-form-label">End Time</label>
                                        <input type="time" name="end_time[]" class="form-control" >
                                        <?php //echo form_error('end_time'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <button type="button" class="btn btn-success" id="add_schrow">+Add More</button>
                            <button type="button" class="btn btn-danger" id="del_schrow">Delete</button>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success mt-1">Save</button>
                        <a href="<?= base_url('admin/schedule') ?>" class="btn btn-secondary mt-1">Cancel</a>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
        <!-- Row closed -->
    </div>
</div>

<script>
    function pre_can_date(){
        var dtToday = new Date();

        var month = dtToday.getMonth() + 1;
        var day = dtToday.getDate();
        var year = dtToday.getFullYear();
        if(month < 10)
            month = '0' + month.toString();
        if(day < 10)
            day = '0' + day.toString();

        var minDate= year + '-' + month + '-' + day;

        jQuery('#sch_date').attr('min', minDate);
    }

    jQuery(document).ready(function(){
        pre_can_date();
        jQuery("#select_ent").change(function(){
            var entID = jQuery(this).val();
            if(entID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Schedule/selectEntityAjax/',
                    type: "POST",
                    data: {
                        ent:entID,
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#depart').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="department"]').append('<option value="'+ value.id +'">'+ value.name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });

        jQuery("#select_department").change(function(){
            var depID = jQuery(this).val();
            var entID = jQuery("#select_ent").find(":selected").val();

            if(depID || entID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Schedule/selectDepartmentAjax/',
                    type: "POST",
                    data: {
                        dep:depID,
                        ent:entID,
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#manager').find('option').not(':first').remove();
                        jQuery('#employee').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="manager"]').append('<option value="'+ value.id +'">'+ value.first_name +' '+ value.last_name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });


        jQuery("#manager").change(function(){
            var managerID = jQuery(this).val();
            var depID = jQuery("#select_department").find(":selected").val();
            var entID = jQuery("#select_ent").find(":selected").val();

            if(depID || entID || managerID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Schedule/selectManagerAjax/',
                    type: "POST",
                    data: {
                        dep:depID,
                        ent:entID,
                        manager:managerID
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#employee').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="employee"]').append('<option value="'+ value.id +'">'+ value.first_name +' '+ value.last_name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });
        
        var s = 2;
        jQuery("#add_schrow").click(function(){
            pre_can_date();
            jQuery('.sch_row .row:last').after('<div class="row"><input type="hidden" name="shift_id[]" value="'+s+'"><div class="col-md-4"><div class="form-group" style="width:100%;"><label for="description" class="col-form-label">Date</label><input type="date" name="date[]" id="sch_date" class="form-control" ></div></div><div class="col-md-4"><div class="form-group" style="width:100%;"><label for="description" class="col-form-label">Start Time</label><input type="time" name="start_time[]" class="form-control" ></div></div><div class="col-md-4"><div class="form-group" style="width:100%;"><label for="description" class="col-form-label">End Time</label><input type="time" name="end_time[]" class="form-control"></div></div></div>');
            s++;
        });

        jQuery("#del_schrow").click(function(){
            if(jQuery('.sch_row .row').length == "1")
            {
                alert("Sorry! Cannot delet main row.");
            }
            else
            {
                jQuery('.sch_row .row:last').remove();
            }
        });
    });
</script>