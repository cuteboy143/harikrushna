<div class="app-content icon-content">
    <div class="p-5"></div>
    <div class="section">
        <!-- Row opened -->
        <div class="row">
            <div class="col-lg-12">
                <?php if ($this->session->flashdata('message') !== NULL) {?>
                    <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <?php print_r($this->session->flashdata('message')['1']);?>
                    </div>
                <?php }?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"><?= $title ?></h3>
                    </div>
                    <?php $attr = array('id' => 'edit_profile');?>
                    <?php echo form_open_multipart(current_url(), $attr); ?>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Entity</label>
                                    <select class="form-control select-2 text-uppercase" name="entity" id="select_ent" readonly>
                                        <option value="" class="text-uppercase">Select Entity</option>
                                        <?php
                                        if(count($entity)>0)
                                        {
                                            foreach($entity as $enti_val)
                                            {
                                                ?>
                                                <option value="<?= $enti_val->id;?>" class="text-uppercase" <?= ($enti_val->id == $schedule->entity) ? "selected" : "";?> > <?= $enti_val->name;?> </option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error('entity'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Deaprtment</label>
                                    <select class="form-control select-2 text-uppercase" name="department" id="select_department" readonly>
                                        <option value="" class="text-uppercase">Select Department</option>
                                        <?php
                                        if(count($department)>0)
                                        {
                                            foreach($department as $de_val)
                                            {
                                                ?>
                                                <option value="<?= $de_val->id;?>" class="text-uppercase" <?= ($de_val->id == $schedule->department) ? "selected" : "";?>><?= $de_val->name;?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error('department'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Manager</label>
                                    <select class="form-control select-2 text-uppercase" name="manager" id="manager" readonly>
                                        <option value="" class="text-uppercase">Select Manager</option>
                                        <?php
                                        if(count($manager)>0)
                                        {
                                            foreach($manager as $man_val)
                                            {
                                                ?>
                                                <option value="<?= $man_val->id;?>" class="text-uppercase" <?= ($man_val->id == $schedule->manager) ? "selected" : "";?>><?= $man_val->first_name." ".$man_val->last_name;?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error('manager'); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group" style="width:100%;">
                                    <label for="description" class="col-form-label">Employee</label>
                                    <select class="form-control select-2 text-uppercase" name="employee" id="employee" readonly>
                                        <option value="" class="text-uppercase">Select Employee</option>
                                        <?php
                                        if(count($employee)>0)
                                        {
                                            foreach($employee as $emp_val)
                                            {
                                                ?>
                                                <option value="<?= $emp_val->id;?>" class="text-uppercase" <?= ($emp_val->id == $schedule->employee) ? "selected" : "";?>><?= $emp_val->first_name." ".$emp_val->last_name;?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                    <?php echo form_error('employee'); ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php 
                        /*$date = json_decode($schedule->date);
                        $start_time = json_decode($schedule->start_time);
                        $end_time = json_decode($schedule->end_time);

                        $sch_arr = array();
                        foreach($date as $date_key => $date_val)
                        {
                            $sch_arr[] = array("date" => $date[$date_key], "start_time" => $start_time[$date_key], "end_time" => $end_time[$date_key]);
                        }*/
                       
                        ?>
                        <div class="sch_row">
                            <?php
                            foreach($schedule_shift as $sch_key => $sch_val)
                            {
                                ?>
                                <div class="row">
                                    <input type="hidden" name="shift_id[]" value="<?php echo $sch_val->shift_id;?>">
                                    <div class="col-md-4">
                                        <div class="form-group" style="width:100%;">
                                            <label for="description" class="col-form-label">Date</label>
                                            <input type="date" name="date[]" class="form-control" id="sch_date" value="<?php echo $sch_val->date;?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group" style="width:100%;">
                                            <label for="description" class="col-form-label">Start Time</label>
                                            <input type="time" name="start_time[]" class="form-control" value="<?php echo $sch_val->start_time;?>">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group" style="width:100%;">
                                            <label for="description" class="col-form-label">End Time</label>
                                            <input type="time" name="end_time[]" class="form-control" value="<?php echo $sch_val->end_time;?>" >
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }?>
                        </div>
                        <div class="col-md-12">
                            <button type="button" class="btn btn-success" id="add_schrow">+Add More</button>
                            <button type="button" class="btn btn-danger" id="del_schrow">Delete</button>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success mt-1">Save</button>
                        <a href="<?= base_url('admin/schedule') ?>" class="btn btn-secondary mt-1">Cancel</a>
                    </div>
                    <?php echo form_close(); ?>
                </div>
            </div>
        </div>
        <!-- Row closed -->
    </div>
</div>

<script>
    jQuery(document).ready(function(){
        jQuery("#select_ent").change(function(){
            var entID = jQuery(this).val();
            if(entID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Employee/selectEntityAjax/',
                    type: "POST",
                    data: {
                        ent:entID,
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#select_department').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="department"]').append('<option value="'+ value.id +'">'+ value.name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });

        jQuery("#select_department").change(function(){
            var depID = jQuery(this).val();
            var entID = jQuery("#select_ent").find(":selected").val();

            if(depID || entID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Employee/selectDepartmentAjax/',
                    type: "POST",
                    data: {
                        dep:depID,
                        ent:entID,
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#manager').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="manager"]').append('<option value="'+ value.id +'">'+ value.first_name +' '+ value.last_name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });

        jQuery("#manager").change(function(){
            var managerID = jQuery(this).val();
            var depID = jQuery("#select_department").find(":selected").val();
            var entID = jQuery("#select_ent").find(":selected").val();

            if(depID || entID || managerID) 
            {
                jQuery.ajax({
                    url: '<?php echo base_url();?>index.php/admin/Schedule/selectManagerAjax/',
                    type: "POST",
                    data: {
                        dep:depID,
                        ent:entID,
                        manager:managerID
                    },
                    dataType: "json",
                    success:function(data) {
                        jQuery('#employee').find('option').not(':first').remove();
                        jQuery.each(data, function(key, value) {
                            jQuery('select[name="employee"]').append('<option value="'+ value.id +'">'+ value.first_name +' '+ value.last_name +'</option>');
                        });
                    }
                });
            }
            else
            {
                location.reload();
            }
        });
        
        var s = jQuery(".sch_row .row").length + 1;
        jQuery("#add_schrow").click(function(){
            jQuery('.sch_row .row:last').after('<div class="row"><input type="hidden" name="shift_id[]" value="'+s+'"><div class="col-md-4"><div class="form-group" style="width:100%;"><label for="description" class="col-form-label">Date</label><input type="date" name="date[]" id="sch_date" class="form-control" ></div></div><div class="col-md-4"><div class="form-group" style="width:100%;"><label for="description" class="col-form-label">Start Time</label><input type="time" name="start_time[]" class="form-control" ></div></div><div class="col-md-4"><div class="form-group" style="width:100%;"><label for="description" class="col-form-label">End Time</label><input type="time" name="end_time[]" class="form-control"></div></div></div>');
            s++;
        });

        jQuery("#del_schrow").click(function(){
            if(jQuery('.sch_row .row').length == "1")
            {
                alert("Sorry! Cannot delet main row.");
            }
            else
            {
                jQuery('.sch_row .row:last').remove();
            }
        });
    });

    /*jQuery(function(){
        var dtToday = new Date();

        var month = dtToday.getMonth() + 1;
        var day = dtToday.getDate();
        var year = dtToday.getFullYear();
        if(month < 10)
            month = '0' + month.toString();
        if(day < 10)
            day = '0' + day.toString();

        var minDate= year + '-' + month + '-' + day;

        jQuery('#sch_date').attr('min', minDate);
    });*/
</script>