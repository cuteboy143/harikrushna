<style>
button.dt-button {
    color: #fff !important;
    background-color: #0576b9 !important;
    border-color: #0576b9 !important;
}
</style>
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Employee Schedule</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"><?php $emp = $this->db->get_where("employee", array("id" => $schedule->employee))->row(); echo $emp->first_name." ".$emp->last_name;?></h4>
                        </div>
                        <div class="card-body">
                            <div class="user-table">
                                <div class="table-responsive">
                                    <table id="emp_sch_table" class="table table-striped table-bordered text-nowrap dataTable no-footer dtr-inline">
                                        <thead>
                                            <tr>
                                                <th>Sr No</th>
                                                <th class="border-bottom-0">Date</th>
                                                <th class="border-bottom-0">Start Time</th>
                                                <th class="border-bottom-0">End Time</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 0; 
                                            if($schedule_shift)
                                            { 
                                                foreach($schedule_shift as $key => $sta)
                                                { 
                                                    $no = $no + 1;?>
                                                    <tr>
                                                        <td><?=$no?></td>
                                                        <td><?= $sta->date;?></td>
                                                        <td><?= date("h:i:s a", strtotime($sta->start_time)); ?></td>
                                                        <td><?= date("h:i:s a", strtotime($sta->end_time)); ?></td>
                                                    </tr>
                                                    <?php 
                                                }
                                            }
                                            else
                                            {
                                                echo "No Data Found!";
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="modal-footer text-center">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
 $('#emp_sch_table').dataTable({
     dom: 'Bfrtip',
        buttons: [
            'excelHtml5',
            'csvHtml5',
        ]
});
});
</script>