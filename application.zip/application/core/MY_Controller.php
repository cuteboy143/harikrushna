<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Controller extends CI_Controller {
	public function __construct() {
		parent::__construct();
		if (empty($this->session->userdata('id'))) 
		{
			redirect('auth/login', 'refresh');
		}
		$this->user = $this->general_model->getOne('users', array('id' => $this->session->userdata('id')));
		$this->manager = $this->general_model->getOne('manager', array('id' => $this->session->userdata('id')));
	}
	
	function send_push_notification($senderids, $title, $description)
	{
        $serverkey = 'AAAABOwDBxU:APA91bGiSKbJLYNJyt0pW01DXDV3nCQXLUqykjbp632vY76xm9l-X1wMK4MtWv4OIkfEg4IvehQO3_bsps9nUZLIaQOO8CH-YrMedNMsc8Qejm7TiHOE96dkzQ3w7qoPUft7n_1SANsf'; // this is a Firebase server key 
        $data = array(
        			'registration_ids' => $senderids,
                     'notification' => 
                     		array(
                     		'title' => $title,
                     		'body' => $description,
                            ),
                            "data"=> array(
                            		/*"click_action"=> "FLUTTER_NOTIFICATION_CLICK",*/
                                    "sound"=> "default", 
                                     "status"=> "done"
                                     )
                            ); 
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"https://fcm.googleapis.com/fcm/send");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,json_encode($data));  //Post Fields
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: key='.$serverkey));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $output = curl_exec ($ch);
        curl_close ($ch);
        return $output;
    }
}

class Public_Controller extends CI_Controller {
	public function __construct() {
		parent::__construct();
	}
}

