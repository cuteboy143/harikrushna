<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Bank Details</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php
$attrib = array('data-toggle' => 'validator', 'role' => 'form', 'data-disable' => 'false', 'id' => 'add_bank');
echo form_open_multipart("", $attrib);
?>
        <div class="modal-body">
       
           
            
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">NAME:</label>
                    <input type="text" name="name" class="form-control" >
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">ADDRESS:</label>
                    <input type="address" name="address" class="form-control" >
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">ACCOUNT NO:</label>
                    <input type="number" name="accountno" class="form-control" >
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">IFSC CODE:</label>
                    <input type="number" name="ifscno" class="form-control" >
                </div>
            </div>
        </div>
        <div class="modal-footer text-center">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        <?php echo form_close(); ?>
    </div>
</div>

<script src="<?=base_url('assets/js/model.js?v=' . time())?>"></script>

