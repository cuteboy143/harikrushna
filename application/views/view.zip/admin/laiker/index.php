<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="app-content icon-content">
    <div class="section">
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url('admin/dashboard'); ?>"><i class="fa fa-cutlery mr-1"></i> Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Laiker</li>
            </ol>
            <div class="mt-3 mt-lg-0">
                <div class="d-flex align-items-center flex-wrap text-nowrap">
                   
                </div>
            </div>
        </div>
        <?php if ($this->session->flashdata('message') !== NULL) { ?>
            <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php print_r($this->session->flashdata('message')['1']); ?>
            </div>
        <?php } ?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Laiker</h4>
                    </div>
                    <div class="card-body">
                        <div class="col-3">
                            <div class="card box-shadow-0 overflow-hidden">
                            <a href="<?= base_url('admin/laiker/add') ?>" class="btn btn-success btn-icon-text mr-2 d-none d-md-block" data-toggle="data-toggle/data-dismiss" data-target="#customModel"> <i class="fe fe-plus"></i> Add laiker</a>
                                <div class="card-body p-4">
                                    <a href="<?= base_url('admin/laiker/') ?>">
                                        <div class="text-center">
                                            <i class="fa fa-users fa-2x text-success dashboarda text-success-shadow"></i>
                                            <div class="card-body">
                        <b><?=$laiker?></b>
                    </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>