<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<script type="text/javascript">
    $(document).ready(function () {
        oTable = $('#tables').dataTable({
            "aaSorting": [[1, "asc"]],
            "stateSave":true,
            "serverSide": true,
            "fixedHeader": true,
            "responsive": true,
            "aLengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            "iDisplayLength": 10,
            'bProcessing': true, 'bServerSide': true,"bDestroy": true,"bRetrieve":true,
            'sAjaxSource': "<?=site_url('admin/questions/getQuestions')?>",
            'fnServerData': function (sSource, aoData, fnCallback) {
                aoData.push({
                    "name": "<?=$this->security->get_csrf_token_name()?>",
                    "value": "<?=$this->security->get_csrf_hash()?>"
                },
                {
                    "name": "role",
                    "value": $("#role_change").val(),
                },
                {
                    "name": "sColumns",
                    "value": "",
                });

                $.ajax({'dataType': 'json', 'type': 'POST', 'url': sSource, 'data': aoData, 'success': fnCallback});
            },
            "columnDefs": [{
                "defaultContent": "-",
                "targets": "_all",
            }],
            "rowReorder": {
                update: false,
                dataSrc: 'order'
            },
            "aoColumns": [
            {
                "bVisible": false,
            },
            {
                "bVisible": false,
            },
            {
                "mRender": text_box_short
            },
            null,
            {
                "mRender": question_action
            },
            ],
            'fnRowCallback': function (nRow, aData, iDisplayIndex) {
                var oSettings = oTable.fnSettings();
                nRow.id = aData[0];
                nRow.className = "user_list";
                return nRow;
            },
            "fnFooterCallback": function (nRow, aaData, iStart, iEnd, aiDisplay) {
                // var nCells = nRow.getElementsByTagName('th');
            },
            "fnDrawCallback": function (nRow, aaData, iStart, iEnd, aiDisplay) {
                $('[data-toggle="popover"]').popover();
                $('[data-toggle="tooltip"]').tooltip();
            }
        });
    });
    $(document).on("change", "#role_change", function () {
        oTable.fnDraw();
    });
    $(document).on('click', 'tr td:first-child', function(){
       $('[data-toggle="popover"]').popover();
       $('[data-toggle="tooltip"]').tooltip();
    });

</script>

<div class="app-content icon-content">
    <div class="section">
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?=base_url('admin/dashboard');?>"><i class="fa fa-cutlery mr-1"></i> Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Questions</li>
            </ol>
             <div class="mt-3 mt-lg-0">
                <div class="d-flex align-items-center flex-wrap text-nowrap">
                    <a href="<?=base_url('admin/questions/add')?>" class="btn btn-success btn-icon-text mr-2 d-none d-md-block" data-toggle="data-toggle/data-dismiss" data-target="#customModel"> <i class="fe fe-plus"></i> Add Question</a>
                </div>
            </div>
        </div>
        <?php if ($this->session->flashdata('message') !== NULL) {?>
            <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php print_r($this->session->flashdata('message')['1']);?>
            </div>
        <?php }?>
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                <?php echo form_open('admin/questions/update_order', 'id="action-form"'); ?>
                    <div class="card-header">
                        <h4 class="card-title">Questions</h4>
                        <div class="card-options">
                            <div class="overflow-hidden">
                               <select class="form-control select2-general" id="role_change" style="width: 150px;">
                                   <option value="">All</option>
                                   <?php if($role){ foreach ($role as $key => $rolea) {?>
                                    <option value="<?=$rolea->id?>"><?=$rolea->name?></option>
                                    <?php } } ?>
                               </select>
                            </div> &nbsp;&nbsp;&nbsp;&nbsp;
                             <button type="button" id="re-order" class="btn btn-primary mb-2 mr-1" data-action="re-order"><i class="mdi mdi-settings"></i> Update Order</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="user-table">
                            <div class="table-responsive">
                                <table id="tables" class="table table-striped table-bordered text-nowrap dataTable no-footer dtr-inline">
                                    <thead>
                                        <tr>
                                            <th></th>
                                             <th></th>
                                            <th class="border-bottom-0">Question</th>
                                            <th class="border-bottom-0">Role</th>
                                            <th class="border-bottom-0">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="form_action" value="" id="form_action"/>
                    <?=form_submit('performAction', 'performAction', 'id="action-form-submit"', 'style="display:none"')?>
                </div>
            </div>
        </div>
    </div>
</div>
