<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Update income</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php
$attrib = array('data-toggle' => 'validator', 'role' => 'form', 'data-disable' => 'false', 'id' => 'add_sales');
echo form_open_multipart("", $attrib);
?>
        <div class="modal-body">
           
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">CompanyName:</label>
                    <input type="text" name="name" value="<?=$sales->name?>" class="form-control" >
                </div>
            </div>
            
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">Address</label>
                    <input type="text" name="address" value="<?=$sales->address?>" class="form-control" >
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">state</label>
                    <input type="text" name="state" value="<?=$sales->state?>" class="form-control" >
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">city</label>
                    <input type="text" name="city" value="<?=$sales->city?>" class="form-control" >
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">zipcode</label>
                    <input type="text" name="zipcode" value="<?=$sales->zipcode?>" class="form-control" >
                </div>
            </div>
              
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">phone</label>
                    <input type="text" name="phone" value="<?=$sales->phone?>" class="form-control" >
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">website</label>
                    <input type="text" name="website" value="<?=$sales->website?>" class="form-control" >
                </div>
            </div>
            
            
        </div>
        <div class="modal-footer text-center">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        <?php echo form_close(); ?>
    </div>
</div>

<script src="<?=base_url('assets/js/model.js?v=' . time())?>"></script>

