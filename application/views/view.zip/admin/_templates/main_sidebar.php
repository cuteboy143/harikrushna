<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar toggle-sidebar">
    <ul class="side-menu toggle-menu">
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/dashboard');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/dashboard.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">DASHBOARD</span>
            </a>
        </li>
        
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/staff');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/customers.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">STAFF</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/rodium');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/categories.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">RODIUM</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/laiker');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/categories.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">LAIKER</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/bank');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/attributes.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">BANK</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/income');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/orders.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">INCOME</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/expansive');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/dashboard.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">EXPANSIVE</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/incomecategory');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/dashboard.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">INCOME CATEGORY</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/expansivecategory');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/dashboard.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">EXPENSE CATEGORY</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/sales');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/categories.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">SALES</span>
            </a>
        </li>
        <li class="slide">
            <a class="side-menu__item" href="<?=base_url('admin/purchase');?>">
                <span class="icon-menu-img"><img src="<?=base_url('assets/images/menu/categories.svg')?>"
                        class="side_menu_img svg-1" alt="image"></span>
                <span class="side-menu__label">Purchase</span>
            </a>
        </li>
       
    </ul>
</aside>
