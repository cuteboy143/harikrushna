<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?=$title?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <div class="row">
                <?php if($pro->picture){ $img = explode(",",$pro->picture); foreach($img as $im){ ?>
                <div class="col-md-3">
                    <img src="<?=base_url('/uploads/product_images/'.$im);?>" >
                </div>
                <?php } } ?>
            </div>
             <div class="card store-items">
                   <div class="card-body">
                      <div class="item-box text-center">
                        <div class="item-box-wrap">
                            <h5 class="mb-2">Purchase id : #<?=$pro->purchase_id?></h5>
                            <span class="mt-1 text-left">
                                <strong>Size</strong> : <?=$pro->size?><br>
                                <strong>Design Code</strong> : <?=$pro->dcode?><br>
                                <strong>PCS</strong> : <?=$pro->pcs?> &nbsp; <strong>Rate</strong> : <?=$pro->rate?>
                            </span>
                           
                         </div>
                      </div>
                   </div>
                </div>
        </div>
    </div>
</div>

<script src="<?=base_url('assets/js/model.js?v=' . time())?>"></script>

