<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><?=$title?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
             <div class="card store-items">
                   <div class="card-body">
                          <?php
$attrib = array('data-toggle' => 'validator', 'role' => 'form', 'data-disable' => 'false', 'id' => '');
echo form_open_multipart("", $attrib);
?>
                      <div class="item-box text-center">
                        <div class="item-box-wrap">
                            <h5 class="mb-2">Purchase id : #<?=$pro->purchase_id?></h5>
                            <label>Sales Team</label>
                            <select name="sales"  class="form-control" required>
                                 <option value="">Select option</option>
                                    <option value="a" class="form-control">A</option>
                                    <option value="b" class="form-control">B</option>
                                    <option value="c" class="form-control">C</option>
                            </select><br>
                             <button type="submit" class="btn btn-primary text-white btn-lg float-right mr-3 mb-2">Submit</button>
                         </div>
                      </div>
                      <?php echo form_close(); ?>
                   </div>
                </div>
        </div>
    </div>
</div>

<script src="<?=base_url('assets/js/model.js?v=' . time())?>"></script>

