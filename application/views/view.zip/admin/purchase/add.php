<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Purchase</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php
$attrib = array('data-toggle' => 'validator', 'role' => 'form', 'data-disable' => 'false', 'id' => 'add_purchase');
echo form_open_multipart("", $attrib);
?>
        <div class="modal-body">
           
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">Picture</label>
                    <input type="file" name="res_image[]" multiple  class="form-control" >
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">Size</label>
                    <input type="text" name="size"  class="form-control" >
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">Disgin code</label>
                    <input type="text" name="dcode"  class="form-control" >
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">PCS</label>
                    <input type="text" name="pcs"  class="form-control" >
                </div>
            </div>
            
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">Rate</label>
                    <input type="text" name="rate"  class="form-control" >
                </div>
            </div>
            
            
        </div>
        <div class="modal-footer text-center">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        <?php echo form_close(); ?>
    </div>
</div>

<script src="<?=base_url('assets/js/model.js?v=' . time())?>"></script>

