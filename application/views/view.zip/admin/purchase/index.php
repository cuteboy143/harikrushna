<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<style type="text/css">
    span.sales_round {
    border: 1px solid #000;
    /* padding: 5px; */
    border-radius: 11px;
    height: 40px;
    font-size: 25px;
    width: 40px;
    text-transform: uppercase;
}
</style>
<div class="app-content icon-content">
    <div class="section">
        <div class="page-header">
            <ol class="breadcrumb">
                <li class="breadcrumb-item1"><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
                <li class="breadcrumb-item1 active"><?= $title ?></li>
            </ol>
            <div class="mt-3 mt-lg-0">
                <div class="d-flex align-items-center flex-wrap text-nowrap">
                    <a href="<?=base_url('admin/purchase/add')?>" class="btn btn-success btn-icon-text mr-2 d-none d-md-block" data-toggle="data-toggle/data-dismiss" data-target="#customModel"><i class="fe fe-plus"></i>Add purchase</a>
                </div>
            </div>
        </div>
        <?php if ($this->session->flashdata('message') !== NULL) {?>
            <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php print_r($this->session->flashdata('message')['1']);?>
            </div>
        <?php }?>
        <div class="row">
            <?php if($purchase){ foreach($purchase as $key => $pro){ ?>
                <div class="col-md-3">
                    <div class="card store-items">
                       <div class="card-body <?php 
                        if($pro->status == 0){
                            echo '';
                        }elseif($pro->status == 1){
                            echo 'bg-warning';
                        }elseif($pro->status == 2){
                            echo 'bg-warning';
                        }elseif($pro->status == 3){
                            echo 'bg-warning';
                        }elseif($pro->status == 4){
                            echo 'bg-success';
                        }
                   ?>">
                          <div class="item-box text-center">
                            <div class="item-box-wrap">
                                <h5 class="mb-2">Purchase id : #<?=$pro->purchase_id?></h5>
                                <span class="mt-1 text-left">
                                    <strong>Size</strong> : <?=$pro->size?><br>
                                    <strong>Design Code</strong> : <?=$pro->dcode?><br>
                                    <strong>PCS</strong> : <?=$pro->pcs?> &nbsp; <strong>Rate</strong> : <?=$pro->rate?>
                                </span>
                                <div class="justify-content-center text-center mt-3 d-flex">
                                    <a href="<?= base_url('admin/purchase/edit/'.$pro->id) ?>" class="btn btn-dark bg-dark pl-3 pr-3 mr-3" data-target="#customModel"data-toggle="data-toggle/data-dismiss" data-toggle="data-toggle/data-dismiss">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="<?= base_url('admin/purchase/delete/'.$pro->id) ?>" class="btn btn-dark bg-dark pl-3 pr-3 mr-3" >
                                        <i class="fa fa-trash"></i>
                                    </a>
                                    <a href="<?= base_url('admin/purchase/view/'.$pro->id) ?>" class="btn btn-dark bg-dark pl-3 pr-3 mr-3" data-target="#customModel"data-toggle="data-toggle/data-dismiss" data-toggle="data-toggle/data-dismiss">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    <?php if($pro->status != 4){?>
                                    <a href="<?= base_url('admin/purchase/plating/'.$pro->id) ?>" class="btn btn-dark  pl-3 pr-3 mr-3" title="Process for Plating">
                                        <i class="fa fa-arrow-right"></i>
                                    </a>
                                    <?php }else{ if(!empty($pro->sale)){ ?>
                                        <span class="sales_round"> <?=$pro->sale;?></span>
                                     <?php }else{ ?>
                                         <a href="<?= base_url('admin/purchase/assign_sales/'.$pro->id) ?>" data-target="#customModel"data-toggle="data-toggle/data-dismiss" data-toggle="data-toggle/data-dismiss" class="btn btn-dark  pl-3 pr-3 mr-3" title="Process for Sales">
                                        <i class="fa fa-shopping-cart"></i>
                                        </a>
                                    <?php } } ?>
                                   
                                </div>
                             </div>
                          </div>
                       </div>
                    </div>
                </div>
            <?php } } ?>
        </div>
    </div>
</div>

<script src="<?=base_url();?>assets/plugins/formwizard/jquery.smartWizard.js"></script>
<script src="<?=base_url();?>assets/plugins/formwizard/fromwizard.js"></script>