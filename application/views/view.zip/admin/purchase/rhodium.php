<link rel="stylesheet" type="text/css" href="<?=base_url('assets/welcome.css')?>">
<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<div class="app-content icon-content">
   <div class="section">
      <div class="page-header">
         <ol class="breadcrumb">
            <li class="breadcrumb-item1"><a href="<?= base_url('admin/dashboard') ?>">Dashboard</a></li>
            <li class="breadcrumb-item1 active"><?= $title ?></li>
         </ol>
         <div class="mt-3 mt-lg-0">
            <div class="d-flex align-items-center flex-wrap text-nowrap">
            </div>
         </div>
      </div>
      <?php if ($this->session->flashdata('message') !== NULL) {?>
      <div class="alert alert-<?php echo $this->session->flashdata('message')['0'] == 1 ? 'success' : 'danger'; ?> alert-dismissible">
         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
         <?php print_r($this->session->flashdata('message')['1']);?>
      </div>
      <?php }?>
      <div class="row">
         <div class="container">
            <div class="welcome main_bar">
               <div class="tabs-left ">
                  <ul class="nav nav-tabs">
                     <li class=""><a href="">Job Sheet</a></li>
                     <li class="active"><a href="">Rhodium</a></li>
                     <li class=""><a href="">Leaker</a></li>
                     <li class=""><a href="">QA & Packaging</a></li>
                  </ul>
                  <div class="tab-content">
                     <div class="tab-pane active">
                        <div class="welcome-screen">
                            <p class="text-left text-dark"><b>Size:</b> <?=$plating->size?>  &nbsp;&nbsp;<b>Disgin Code:</b> <?=$plating->dcode?>  &nbsp;&nbsp;<b>Rate:</b> <?=$plating->rate?> </p>
                             <div class="user-table">
                                    <div class="table-responsive">
                                        <table id="tables" class="table table-striped table-bordered text-nowrap dataTable no-footer dtr-inline">
                                                <tr>
                                                    <th>Sr No</th>
                                                    <th class="border-bottom-0">Clinging</th>
                                                    <th class="border-bottom-0">Weight</th>
                                                    <th class="border-bottom-0">Rhodium</th>
                                                </tr>
                                            <tbody>
                                                <form method="post">
                                                <?php $i = 1; for($i; $i<=$plating->pcs; $i++){?>
                                                   <?php $clening = $this->db->get_where('plating',array('purchase_id' => $this->uri->segment(4),'pid' => $i))->row();?>
                                                <tr>
                                                    <td><?=$i;?></td>=
                                                    <td><?php if($clening){
                                                      if($clening->clining == 1){
                                                         echo 'Done';
                                                      }else{
                                                         echo 'Pendding';
                                                      }
                                                    }?></td>
                                                    <td><?php if($clening){
                                                      echo $clening->weight;
                                                    }?></td>
                                                    <td><input type="text" name="rhodium[<?=$i?>]"  class="form-control"  onkeypress="return isNumberKey(this, event);" ></td>
                                                </tr>
                                                <?php } ?>
                                                
                                            </tbody>
                                           
                                        </table>
                                         <button type="submit" class="btn btn-primary text-white btn-lg float-right mr-3 mb-2">Update</button>
                                                </form>
                                    </div>
                                </div>
                        </div>
                     </div>
                  </div>
                  
               </div>
            </div>
            <!-- col end -->
         </div>
      </div>
   </div>
</div>

 <script type="text/javascript">
    function isNumberKey(txt, evt) {
      var charCode = (evt.which) ? evt.which : evt.keyCode;
      if (charCode == 46) {
        //Check if the text already contains the . character
        if (txt.value.indexOf('.') === -1) {
          return true;
        } else {
          return false;
        }
      } else {
        if (charCode > 31 &&
          (charCode < 48 || charCode > 57))
          return false;
      }
      return true;
    }
  </script>