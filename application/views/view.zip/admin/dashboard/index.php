<div class="app-content icon-content">
    <div class="p-5"></div>
    <div class="section">
        <div class="row">
            <div class="col-3">
               <div class="card box-shadow-0 overflow-hidden">
                  <div class="card-body p-4">
                    <a href="<?=base_url('admin/candidates/filter_candidates/1')?>">
                    <div class="text-center">
                        <i class="fa fa-users fa-2x text-primary dashboarda text-success-shadow"></i>
                        <h3 class="mt-3 mb-0 ">1</h3>
                        <small class="text-muted">Daily Candidates</small>
                     </div>
                    </a>
                  </div>
               </div>
            </div>
            <div class="col-3">
               <div class="card box-shadow-0 overflow-hidden">
                  <div class="card-body p-4">
                    <a href="<?=base_url('admin/candidates/filter_candidates/2')?>">
                     <div class="text-center">
                        <i class="fa fa-users fa-2x text-success dashboarda text-success-shadow"></i>
                        <h3 class="mt-3 mb-0 ">1</h3>
                        <small class="text-muted">Weekly Candidates</small>
                     </div>
                    </a>
                  </div>
               </div>
            </div>
            <div class="col-3">
               <div class="card box-shadow-0 overflow-hidden">
                  <div class="card-body p-4">
                    <a href="<?=base_url('admin/candidates/filter_candidates/3')?>">
                     <div class="text-center">
                        <i class="fa fa-users fa-2x text-primary dashboarda text-success-shadow"></i>
                        <h3 class="mt-3 mb-0 ">1</h3>
                        <small class="text-muted">Monthly Candidates</small>
                     </div>
                    </a>
                  </div>
               </div>
            </div>
            <div class="col-3">
               <div class="card box-shadow-0 overflow-hidden">
                  <div class="card-body p-4">
                    <a href="<?=base_url('admin/candidates/filter_candidates/4')?>">
                     <div class="text-center">
                        <i class="fa fa-users fa-2x text-success dashboarda text-success-shadow"></i>
                       <h3 class="mt-3 mb-0 ">1</h3>
                        <small class="text-muted">Yearly Candidates</small>
                     </div>
                    </a>
                  </div>
               </div>
            </div>
            <div class="col-3">
               <div class="card box-shadow-0 overflow-hidden">
                  <div class="card-body p-4">
                    <a href="<?=base_url('admin/application')?>">
                     <div class="text-center">
                        <i class="fa fa-list-alt fa-2x text-success dashboarda text-success-shadow"></i>
                       <h3 class="mt-3 mb-0 ">1</h3>
                        <small class="text-muted">Total Applications</small>
                     </div>
                    </a>
                  </div>
               </div>
            </div>

            <div class="col-3">
               <div class="card box-shadow-0 overflow-hidden">
                  <div class="card-body p-4">
                    <a href="<?=base_url('admin/application/pendding_appliction')?>">
                     <div class="text-center">
                        <i class="fa fa-list-alt fa-2x text-primary dashboarda text-success-shadow"></i>
                       <h3 class="mt-3 mb-0 ">1</h3>
                        <small class="text-muted">Pending Applications</small>
                     </div>
                    </a>
                  </div>
               </div>
            </div>

        </div>
    </div>
</div>
