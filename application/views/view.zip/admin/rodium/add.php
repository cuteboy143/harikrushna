<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Rodium</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php
$attrib = array('data-toggle' => 'validator', 'role' => 'form', 'data-disable' => 'false', 'id' => 'add_rodium');
echo form_open_multipart("", $attrib);
?>
        <div class="modal-body">
            <!-- <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">Role</label>
                    <select class="form-control select-2 text-uppercase" name="role">
                        <option value="" class="text-uppercase">Select Role</option>
                        <option value="0" class="text-uppercase">General Question</option>
                        <?php if($role){ foreach ($role as $key => $value) { ?>
                        <option  class="text-uppercase" value="<?=$value->id?>"><?=$value->name?></option>
                        <?php } } ?>
                    </select>
                </div>
            </div> -->
            <div class="col-md-12">
                <div class="form-group" style="width:100%;">
                    <label for="description" class="col-form-label">Amount</label>
                    <input type="text" name="amount" class="form-control" >
                </div>
            </div>
        </div>
        <div class="modal-footer text-center">
            <button type="submit" class="btn btn-success">Save</button>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        <?php echo form_close(); ?>
    </div>
</div>

<script src="<?=base_url('assets/js/model.js?v=' . time())?>"></script>

