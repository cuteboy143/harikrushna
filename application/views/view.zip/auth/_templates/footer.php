<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<script src="<?= base_url('assets/js/vendors/jquery-3.2.1.min.js'); ?>"></script>
<script src="<?= base_url('assets/plugins/bootstrap-4.1.3/js/bootstrap.min.js'); ?>"></script>
</body>
</html>
